import 'package:flutter/material.dart';

class W2 extends StatelessWidget {
  const W2({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("W2"),
      ),
      body: Container(
        color: Colors.orange,
      ),
    );
    
  }
}
