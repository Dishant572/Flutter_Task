import 'package:flutter/material.dart';

class W1 extends StatelessWidget {
  final int number;
  
  const W1({required this.number});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(this.number.toString()),
      ),
      body: Container(
        color: Colors.blue,
        
        
        ),
      );
      
  }
}
