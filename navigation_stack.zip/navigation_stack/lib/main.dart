import 'package:flutter/material.dart';
import 'package:navigation_stack/widget/w1.dart';
import 'package:navigation_stack/widget/w2.dart';

void main() {
  runApp(MaterialApp(
    initialRoute: '/',
    routes: {
      '/': (context) => MainApp(),
      '/W1': (context) => W1(
            number: 66,
          ),
      '/W2': (context) => W2(),
    },
  ));
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Wrap(direction: Axis.vertical, children: [
          Text('Hello World!'),
          ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/W1');
              },
              child: Text("Press Me to go W1")),

          ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/W2');
              },
              child: Text("Press Me to go W2"))
        ]),
      ),
    );
  }
}
