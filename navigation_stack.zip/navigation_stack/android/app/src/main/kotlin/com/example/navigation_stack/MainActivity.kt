package com.example.navigation_stack

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
